package e.kyleg.obfuscationapp.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import e.kyleg.obfuscationapp.R;
import e.kyleg.obfuscationapp.api.GetMentions;

public class HomeFragment extends Fragment implements GetMentions.AsyncResponse {

    // private HomeViewModel homeViewModel;
    private GetMentions getMentionsAsync = new GetMentions();
    private ListView mentionsList;
    private ArrayAdapter itemsAdapter;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        try {
            getMentionsAsync.execute().get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // homeViewModel = ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        getMentionsAsync.delegate = this;

        mentionsList = root.findViewById(R.id.list_view);

        return root;
    }

    @Override
    public void processFinish(ArrayList output) {
        System.out.println("Hello, here is the data");
        itemsAdapter = new ArrayAdapter(getActivity().getBaseContext(), android.R.layout.simple_list_item_1, output);
        mentionsList.setAdapter(itemsAdapter);
    }
}
