package e.kyleg.obfuscationapp.api;

import android.os.AsyncTask;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class GetMentions extends AsyncTask<Void, Void, ArrayList> {

    public interface AsyncResponse {
        void processFinish(ArrayList output);
    }

    public AsyncResponse delegate = null;
    private ArrayList values;

    @Override
    protected ArrayList doInBackground(Void... voids) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("reddit-mentions");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                values = (ArrayList) dataSnapshot.getValue();
                //System.out.println("Value is: " + values);
                delegate.processFinish(values);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Failed to read value
                System.out.println("Failed to read value." + error.toException());
            }
        });
        return values;
    }

    /*@Override
    protected void onPostExecute(ArrayList result) {
        System.out.println("Whaddup here's the data");
        System.out.println(result);
        delegate.processFinish(result);
    }*/
}
